#!/bin/sh
java -jar newrelic_mysql_plugin-0.8.1-beta.jar
