#!/bin/sh
java -jar newrelic_mysql_plugin-beta.jar
